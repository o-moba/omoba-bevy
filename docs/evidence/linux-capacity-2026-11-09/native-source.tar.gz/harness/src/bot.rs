//! A scripted bot client: one connected [`UdpSocket`] plus typed helpers for
//! every `ClientPacket` the harness needs, and polling helpers for reading
//! `Snapshot` packets back from the server.
//!
//! Network reads use a short socket timeout and the higher-level helpers
//! ([`Bot::recv_snapshot`], [`Bot::wait_for_player`]) poll until a deadline, so
//! tests stay deterministic without sleeping blindly. Network calls use
//! `expect` with descriptive messages rather than bare `unwrap`.

use std::{
    cell::RefCell,
    io::{self, ErrorKind},
    net::{SocketAddr, UdpSocket},
    time::{Duration, Instant},
};

use crate::protocol::{
    Character, ClientPacket, HeroClass, PlayerState, ServerPacket, SnapshotView, TargetId, Team,
};

/// Per-recv socket timeout. Snapshots arrive every ~50ms, so this is short
/// enough to poll responsively and long enough to avoid busy-spinning.
const RECV_TIMEOUT: Duration = Duration::from_millis(200);

/// Largest legal application payload in one IPv4 UDP datagram.
pub const IPV4_UDP_MAX_PAYLOAD_BYTES: usize = 65_507;
/// Storage exceeds the legal payload limit, preventing prefix truncation.
const DATAGRAM_RECEIVE_CAPACITY: usize = 65_536;

/// Monotonic received-wire counters, including lobby/auth traffic. Safe for
/// load telemetry: no packet contents, identities or session credentials.
#[derive(Debug, Clone, Copy, Default, PartialEq, Eq, serde::Serialize)]
pub struct TransportStats {
    pub received_datagrams: u64,
    pub received_bytes: u64,
    pub accepted_snapshots: u64,
    pub decode_errors: u64,
    pub framing_errors: u64,
}

/// A connected bot client.
pub struct Bot {
    socket: UdpSocket,
    public: Option<RefCell<crate::public_client::PublicSession>>,
    /// Cached own player id, learned from the first snapshot.
    my_id: Option<u64>,
    /// Reusable receive buffer, allocated once instead of per `recv` call.
    recv_buf: Vec<u8>,
    assembler: shared::transport::SnapshotAssembler,
    order: shared::protocol::SnapshotOrder,
    framed: bool,
    dash_sequence: u64,
    transport_stats: TransportStats,
    last_snapshot_meta: Option<shared::protocol::SnapshotMeta>,
}

impl Bot {
    /// Connects a new bot to the given server address.
    pub fn connect(server_addr: SocketAddr) -> Self {
        let socket = UdpSocket::bind(if server_addr.is_ipv4() {
            "0.0.0.0:0"
        } else {
            "[::]:0"
        })
        .expect("bot failed to bind a socket");
        socket
            .connect(server_addr)
            .expect("bot failed to connect to the server address");
        socket
            .set_read_timeout(Some(RECV_TIMEOUT))
            .expect("bot failed to set a socket read timeout");
        Self {
            socket,
            public: None,
            my_id: None,
            recv_buf: vec![0u8; DATAGRAM_RECEIVE_CAPACITY],
            assembler: Default::default(),
            order: Default::default(),
            framed: false,
            dash_sequence: 0,
            transport_stats: TransportStats::default(),
            last_snapshot_meta: None,
        }
    }

    /// Uses the current ordered, MTU-safe snapshot protocol. Legacy connect
    /// remains available for compatibility and host datagram-budget probes.
    pub fn connect_framed(server_addr: SocketAddr) -> Self {
        let mut bot = Self::connect(server_addr);
        bot.framed = true;
        bot.ping();
        bot
    }

    /// Starts an asynchronous signed lobby handshake. Call `ping` and
    /// `recv_snapshot` for every bot while waiting; no roster blocks creation
    /// of its remaining peers. Public fill clients explicitly accept each
    /// ready check, then lock and load their selected hero in the worker.
    pub fn connect_public(
        server_addr: SocketAddr,
        preference: shared::match_service::MatchPreference,
        class: HeroClass,
        nickname: String,
    ) -> Self {
        let mut bot = Self::connect(server_addr);
        bot.framed = true;
        bot.public = Some(RefCell::new(crate::public_client::PublicSession::new(
            preference, class, nickname,
        )));
        bot.ping();
        bot
    }

    pub fn enable_ranked_eligibility_probe(&self, lobby: SocketAddr) {
        self.public
            .as_ref()
            .expect("public session required")
            .borrow_mut()
            .enable_eligibility_probe(lobby);
    }

    pub fn public_status(&self) -> Option<crate::PublicBotStatus> {
        self.public
            .as_ref()
            .map(|session| session.borrow().status_view())
    }

    /// Owned loopback load fixtures may finish sign-in before pressing Search.
    /// Authentication, signed keepalives and normal consent remain active.
    pub fn set_public_search_enabled(&self, enabled: bool) {
        assert!(self.socket.peer_addr().unwrap().ip().is_loopback());
        self.public
            .as_ref()
            .expect("public session required")
            .borrow_mut()
            .set_search_enabled(enabled);
    }

    pub fn transport_stats(&self) -> TransportStats {
        self.transport_stats
    }

    /// Latest fully decoded, ordered and authorized snapshot. Observing the
    /// producer tick separately from accepted counts distinguishes slow server
    /// broadcasts from missing complete snapshots at the load generator.
    pub fn snapshot_meta(&self) -> Option<shared::protocol::SnapshotMeta> {
        self.last_snapshot_meta
    }

    pub fn public_running(&self) -> bool {
        self.public.as_ref().is_some_and(|session| {
            let session = session.borrow();
            session.status.phase == "running" && session.status.error.is_none()
        })
    }

    fn record_receive(&mut self, len: usize) {
        self.transport_stats.received_datagrams =
            self.transport_stats.received_datagrams.saturating_add(1);
        self.transport_stats.received_bytes = self
            .transport_stats
            .received_bytes
            .saturating_add(len as u64);
    }

    fn decode_received(&mut self, len: usize) -> Option<ServerPacket> {
        let bytes = match self.assembler.push(&self.recv_buf[..len], Instant::now()) {
            Ok(bytes) => bytes?,
            Err(_) => {
                self.transport_stats.framing_errors =
                    self.transport_stats.framing_errors.saturating_add(1);
                return None;
            }
        };
        if let Some(session) = &self.public
            && let Ok(packet) =
                serde_json::from_slice::<shared::public_transport::PublicServerDatagram>(&bytes)
        {
            session.borrow_mut().transport(&self.socket, packet);
            return None;
        }
        let packet: ServerPacket = match serde_json::from_slice(&bytes) {
            Ok(packet) => packet,
            Err(error) => {
                self.transport_stats.decode_errors =
                    self.transport_stats.decode_errors.saturating_add(1);
                if self.transport_stats.decode_errors == 1 {
                    eprintln!(
                        "bot: dropping undecodable server packet ({error}); \
                         later decode failures are counted, not logged"
                    );
                }
                return None;
            }
        };
        if let Some(session) = &self.public
            && let ServerPacket::Career {
                server_epoch,
                sequence,
                career,
            } = packet
        {
            if let Some(endpoint) =
                session
                    .borrow_mut()
                    .career_packet(server_epoch, sequence, career)
            {
                self.socket
                    .connect(endpoint)
                    .expect("connect allocated worker");
                self.assembler = Default::default();
                self.order = Default::default();
                self.my_id = None;
                self.last_snapshot_meta = None;
                self.dash_sequence = 0;
            }
            return None;
        }
        // Scenarios read gameplay snapshots; social and career envelopes use
        // their own datagram paths and are not surfaced here.
        if !matches!(packet, ServerPacket::Snapshot { .. }) {
            return None;
        }
        if self
            .public
            .as_ref()
            .is_some_and(|session| !session.borrow().accepts(packet.meta().server_epoch))
        {
            return None;
        }
        if (self.framed || packet.meta().protocol_version != 0) && !self.order.accept(packet.meta())
        {
            return None;
        }
        if let Some(session) = &self.public {
            session.borrow_mut().snapshot(&self.socket, &packet);
        }
        self.dash_sequence = packet
            .players()
            .iter()
            .find(|p| p.id == packet.your_id())
            .map_or(0, |p| p.utility.dash_sequence);
        self.transport_stats.accepted_snapshots =
            self.transport_stats.accepted_snapshots.saturating_add(1);
        self.last_snapshot_meta = Some(packet.meta());
        Some(packet)
    }

    // --- Outbound packet helpers -------------------------------------------

    fn send(&self, packet: &ClientPacket) -> bool {
        if let Some(session) = &self.public {
            return session.borrow_mut().send(&self.socket, packet);
        }
        let bytes = serde_json::to_vec(packet).expect("client packet should serialize to JSON");
        self.socket
            .send(&bytes)
            .expect("bot failed to send packet to the server");
        true
    }

    /// Negotiates coordinated draft and automatic server-side team assignment.
    pub fn join_draft(
        &self,
        character: Character,
        hero_class: HeroClass,
        session_id: Option<String>,
    ) {
        self.send(&ClientPacket::Join {
            handheld: Default::default(),
            prematch: true,
            team: Team::Green,
            character,
            hero_class,
            avatar: None,
            sprite_character: None,
            session_id,
            passport_ticket: None,
        });
    }

    pub fn prematch(&self, request: shared::prematch::PrematchRequest) {
        self.send(&ClientPacket::Prematch { request });
    }

    /// Joins a team as the given character with the default loadout
    /// (Warrior class, no roster avatar).
    pub fn join(&self, team: Team, character: Character) {
        self.join_with_loadout(team, character, HeroClass::Warrior, None);
    }

    /// Joins a team with an explicit class and (optional) roster avatar slug.
    pub fn join_with_loadout(
        &self,
        team: Team,
        character: Character,
        hero_class: HeroClass,
        avatar: Option<&str>,
    ) {
        self.join_with_cosmetics(team, character, hero_class, avatar, None);
    }

    /// Joins with independent 3D-avatar and 2D-sprite cosmetic identities.
    pub fn join_with_cosmetics(
        &self,
        team: Team,
        character: Character,
        hero_class: HeroClass,
        avatar: Option<&str>,
        sprite_character: Option<&str>,
    ) {
        self.send(&ClientPacket::Join {
            handheld: Default::default(),
            prematch: false,
            team,
            character,
            hero_class,
            avatar: avatar.map(str::to_owned),
            sprite_character: sprite_character.map(str::to_owned),
            session_id: None,
            passport_ticket: None,
        });
    }

    /// Sends a raw datagram as-is (for malformed/hostile input scenarios).
    pub fn send_raw(&self, bytes: &[u8]) {
        self.socket
            .send(bytes)
            .expect("bot failed to send raw packet to the server");
    }

    /// Sends a movement/orientation update.
    pub fn send_transform(&self, x: f32, y: f32, z: f32, yaw: f32) {
        self.try_send_transform_with_activity(x, y, z, yaw, true);
    }

    /// Returns false when a public session has no current signing authority.
    /// The native game sends an idle pose even while dead; idle input must not
    /// fabricate AFK activity. Counts advance only after the signed UDP send.
    pub fn try_send_transform_with_activity(
        &self,
        x: f32,
        y: f32,
        z: f32,
        yaw: f32,
        active: bool,
    ) -> bool {
        self.send(&ClientPacket::Transform {
            input_kind: Default::default(),
            input_active: active,
            x,
            y,
            z,
            yaw,
            dash_sequence: self.dash_sequence,
        })
    }

    /// Casts the Q ability at a target.
    pub fn cast(&self, target: TargetId) {
        self.cast_slot(target, 0);
    }

    /// Casts the ability in the given hotbar slot (0=Q .. 3=R) at a target.
    pub fn cast_slot(&self, target: TargetId, slot: u8) {
        self.send(&ClientPacket::Cast { target, slot });
    }

    /// Convenience: cast the Q ability at an enemy player by id.
    pub fn cast_player(&self, player_id: u64) {
        self.cast(TargetId::player(player_id));
    }

    /// Requests a skill upgrade for the given slot (0=Q, 1=W, 2=E, 3=R).
    pub fn upgrade_skill(&self, slot: u8) {
        self.send(&ClientPacket::UpgradeSkill { slot });
    }

    /// Retries reuse both request and round identity until a receipt arrives.
    pub fn buy_item(
        &self,
        item: shared::shop::ItemId,
        request_id: u64,
        match_id: u64,
        server_epoch: u64,
    ) {
        self.send(&ClientPacket::BuyItem {
            item_id: item.id().to_owned(),
            request_id,
            match_id,
            server_epoch,
        });
    }

    /// Toggles the debug invulnerability ("god mode") flag.
    pub fn set_god_mode(&self, enabled: bool) {
        self.send(&ClientPacket::SetGodMode { enabled });
    }

    /// Toggles the debug movement speed boost.
    pub fn set_speed_boost(&self, enabled: bool) {
        self.send(&ClientPacket::SetSpeedBoost { enabled });
    }

    /// Sends a keep-alive ping (also registers the bot with the server).
    pub fn ping(&self) {
        if let Some(session) = &self.public {
            session.borrow_mut().tick(&self.socket);
            return;
        }
        if self.framed {
            self.send(&ClientPacket::Hello {
                protocol_version: shared::protocol::PROTOCOL_VERSION,
            });
        } else {
            self.send(&ClientPacket::Ping);
        }
    }

    // --- Inbound snapshot helpers ------------------------------------------

    fn prepare_read(&self, deadline: Instant) -> bool {
        let remaining = deadline.saturating_duration_since(Instant::now());
        if remaining.is_zero() {
            return false;
        }
        // One idle lobby peer must not consume the fixed200ms socket timeout
        // when the multi-peer driver only gave it a20ms polling budget.
        self.socket
            .set_read_timeout(Some(remaining.min(RECV_TIMEOUT)))
            .expect("bot failed to apply remaining receive deadline");
        true
    }

    /// Receives one complete raw datagram for transport-level assertions.
    /// Invalid JSON is returned unchanged and is never treated as a snapshot.
    pub fn recv_raw_datagram(&mut self, deadline: Instant) -> Option<Vec<u8>> {
        loop {
            if !self.prepare_read(deadline) {
                return None;
            }
            match self.socket.recv(&mut self.recv_buf) {
                Ok(len) => {
                    self.record_receive(len);
                    return Some(self.recv_buf[..len].to_vec());
                }
                Err(error) if is_timeout(&error) => {}
                Err(error) => panic!("bot socket raw recv failed: {error}"),
            }
        }
    }

    /// Returns the **freshest** snapshot available before `deadline`.
    ///
    /// The server emits a snapshot every ~50ms, so a bot's socket buffer can
    /// hold a backlog of stale snapshots after it has been idle. This blocks
    /// for at least one snapshot, then drains any further buffered snapshots
    /// without blocking and returns the most recent one — so callers always
    /// assert against current server state, never lagged history.
    pub fn recv_snapshot(&mut self, deadline: Instant) -> Option<ServerPacket> {
        let mut latest = self.recv_one_blocking(deadline)?;

        // Drain anything already buffered to catch up to the newest snapshot.
        self.socket
            .set_nonblocking(true)
            .expect("bot failed to switch socket to non-blocking for draining");
        loop {
            match self.socket.recv(&mut self.recv_buf) {
                Ok(len) => {
                    self.record_receive(len);
                    if let Some(packet) = self.decode_received(len) {
                        latest = packet;
                    }
                }
                Err(error) if is_timeout(&error) => break,
                Err(error) => panic!("bot socket recv failed while draining: {error}"),
            }
        }
        // Restore blocking mode. The next blocking receive derives its timeout
        // from that call's deadline, independently of the non-blocking flag.
        self.socket
            .set_nonblocking(false)
            .expect("bot failed to restore blocking socket mode after draining");

        self.my_id = Some(latest.your_id());
        Some(latest)
    }

    /// Drain currently buffered input without waiting for another network
    /// update. Fixed-cadence controllers must not pay one socket timeout for
    /// each idle peer. Bound work so a busy socket cannot starve their inputs.
    pub fn poll_snapshot(&mut self) -> Option<ServerPacket> {
        self.socket
            .set_nonblocking(true)
            .expect("nonblocking bot poll");
        let deadline = Instant::now() + Duration::from_millis(2);
        let mut latest = None;
        for _ in 0..256 {
            if Instant::now() >= deadline {
                break;
            }
            match self.socket.recv(&mut self.recv_buf) {
                Ok(len) => {
                    self.record_receive(len);
                    if let Some(packet) = self.decode_received(len) {
                        latest = Some(packet);
                    }
                }
                Err(error) if is_timeout(&error) => break,
                Err(error) => panic!("bot socket poll failed: {error}"),
            }
        }
        self.socket
            .set_nonblocking(false)
            .expect("restore bot blocking mode");
        if let Some(packet) = &latest {
            self.my_id = Some(packet.your_id());
        }
        latest
    }

    /// Blocks until one snapshot arrives or `deadline` passes. Non-snapshot or
    /// unparsable datagrams are skipped.
    fn recv_one_blocking(&mut self, deadline: Instant) -> Option<ServerPacket> {
        loop {
            if !self.prepare_read(deadline) {
                return None;
            }
            match self.socket.recv(&mut self.recv_buf) {
                Ok(len) => {
                    self.record_receive(len);
                    if let Some(packet) = self.decode_received(len) {
                        return Some(packet);
                    }
                    // Unknown/garbage datagram: keep polling.
                }
                Err(error) if is_timeout(&error) => {
                    // No datagram this interval; loop until the deadline.
                }
                Err(error) => panic!("bot socket recv failed: {error}"),
            }
        }
    }

    /// Returns this bot's own player id, blocking (with a timeout) until the
    /// first snapshot is seen.
    pub fn my_id(&mut self, timeout: Duration) -> u64 {
        if let Some(id) = self.my_id {
            return id;
        }
        let deadline = Instant::now() + timeout;
        self.recv_snapshot(deadline)
            .map(|packet| packet.your_id())
            .expect("bot did not receive any snapshot within the timeout")
    }

    /// Polls snapshots until `predicate` holds for the player with `id`, then
    /// returns that player's state. Returns `None` on timeout.
    pub fn wait_for_player<F>(
        &mut self,
        id: u64,
        mut predicate: F,
        timeout: Duration,
    ) -> Option<PlayerState>
    where
        F: FnMut(&PlayerState) -> bool,
    {
        let deadline = Instant::now() + timeout;
        while let Some(packet) = self.recv_snapshot(deadline) {
            if let Some(player) = packet.player(id)
                && predicate(player)
            {
                return Some(player.clone());
            }
        }
        None
    }

    /// Reads the latest available player state for `id` within `timeout`.
    pub fn latest_player(&mut self, id: u64, timeout: Duration) -> Option<PlayerState> {
        self.wait_for_player(id, |_| true, timeout)
    }
}

/// Treats both `WouldBlock` (Unix `SO_RCVTIMEO`) and `TimedOut` (Windows) as a
/// "no datagram yet" signal.
fn is_timeout(error: &io::Error) -> bool {
    matches!(error.kind(), ErrorKind::WouldBlock | ErrorKind::TimedOut)
}
