//! Private immutable allocation manifest and atomic worker lifecycle receipts.
use std::collections::HashSet;
use std::io::Write;
use std::net::SocketAddr;
use std::path::{Path, PathBuf};
use std::time::Instant;
use std::{fs, io};

use serde::{Deserialize, Serialize};
use shared::career::valid_profile_id;
use shared::map::Team;
use shared::match_service::MatchPreference;
use shared::wire::ClientPacket;

use crate::runtime::ServerRuntime;
use crate::session::normalize_session_id;

pub(crate) mod releases;

pub(crate) fn unix_ms() -> u64 {
    std::time::SystemTime::now()
        .duration_since(std::time::UNIX_EPOCH)
        .unwrap_or_default()
        .as_millis()
        .min(u64::MAX as u128) as u64
}
#[derive(Clone, Debug, Serialize, Deserialize, PartialEq, Eq)]
pub(crate) struct AllocatedHuman {
    pub profile_id: String,
    pub session_id: String,
    pub team: shared::map::Team,
}
#[derive(Clone, Debug, Serialize, Deserialize)]
pub(crate) struct Manifest {
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub ranked_season_id: Option<u64>,
    pub version: u32,
    pub allocation_id: String,
    pub endpoint: String,
    pub bind: String,
    pub preference: MatchPreference,
    pub humans: Vec<AllocatedHuman>,
    pub join_deadline_ms: u64,
    /// The widened rated cohort a Ranked roster was formed with (LR-35):
    /// `[spread, merge_newcomers]`, absent for the base cohort and for every
    /// other queue. Additive: older manifests on disk read as the base.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub cohort: Option<(i32, bool)>,
}
impl Manifest {
    pub fn validate(&self) -> Result<(), String> {
        let ids: HashSet<_> = self.humans.iter().map(|h| &h.profile_id).collect();
        let sessions: HashSet<_> = self.humans.iter().map(|h| &h.session_id).collect();
        if self.ranked_season_id.is_some_and(|id| id == 0 || id > i64::MAX as u64 || !self.preference.rated())
            || self.version != 1
            || self.allocation_id.len() != 32
            || !self.allocation_id.bytes().all(|b| b.is_ascii_hexdigit())
            || self.humans.is_empty()
            || self.humans.len() > 10
            || ids.len() != self.humans.len()
            || sessions.len() != self.humans.len()
            || self.bind.parse::<SocketAddr>().is_err()
            || self.endpoint.len() > 253
            || self.endpoint.contains(['/', '\n', '\r'])
            || self.humans.iter().any(|h| {
                !valid_profile_id(&h.profile_id)
                    || normalize_session_id(Some(h.session_id.clone())).as_ref()
                        != Some(&h.session_id)
            })
            || [shared::map::Team::Green, shared::map::Team::Blue]
                .iter()
                .any(|t| self.humans.iter().filter(|h| h.team == *t).count() > 5)
            // Ranked is ten humans; it is never filled with bots.
            || (self.preference == MatchPreference::Ranked && self.humans.len() != 10)
            // A widened cohort belongs to Ranked and stays within the policy's caps.
            || self.cohort.is_some_and(|(spread, _)| {
                self.preference != MatchPreference::Ranked
                    || !(omoba_career_store::matchmaking::MAX_RATING_SPREAD
                        ..=omoba_career_store::matchmaking::MAX_WIDENED_SPREAD)
                        .contains(&spread)
            })
            // Bot practice seats one player or one party, all on one team.
            || (self.preference == MatchPreference::BotPractice
                && (self.humans.len() > shared::party::MAX_PARTY_SIZE
                    || self.humans.iter().any(|h| h.team != self.humans[0].team)))
        {
            return Err("Invalid allocated match manifest".into());
        }
        Ok(())
    }
    /// The worker's match mode (LR-08). Only Ranked runs the rated release
    /// rules. Casual PvP and vs Bots run worker practice rules: bots take the
    /// empty seats (none when ten humans queued Casual), and the round settles
    /// as `public-casual-v1`, never rated.
    pub fn match_mode(&self) -> crate::match_rules::MatchMode {
        if self.preference.rated() {
            crate::match_rules::MatchMode::Release
        } else {
            crate::match_rules::MatchMode::Practice
        }
    }
    pub fn read(path: &Path) -> Result<Self, String> {
        let bytes = fs::read(path).map_err(|_| "Cannot read allocation manifest")?;
        if bytes.len() > 16384 {
            return Err("Allocation manifest too large".into());
        }
        let value: Self = serde_json::from_slice(&bytes).map_err(|_| "Invalid allocation JSON")?;
        value.validate()?;
        Ok(value)
    }
    pub fn team(&self, profile: &str, session: &str) -> Option<Team> {
        self.humans
            .iter()
            .find(|h| h.profile_id == profile && h.session_id == session)
            .map(|h| h.team)
    }
}
#[derive(Clone, Debug, Serialize, Deserialize, PartialEq, Eq)]
#[serde(rename_all = "snake_case")]
pub(crate) enum Phase {
    Ready,
    Forming,
    Running,
    Settling,
    Finished,
    Failed,
    Recovering,
}
#[derive(Clone, Debug, Serialize, Deserialize)]
pub(crate) struct Status {
    pub allocation_id: String,
    pub server_epoch: u64,
    pub heartbeat_ms: u64,
    pub phase: Phase,
    pub result_id: Option<String>,
    /// While `running`: the Unix time (ms) by which the match ends at the
    /// latest, its duration cap or, while no human is connected, the
    /// abandoned-match reaping. The lobby shows it to a player who left (LR-13).
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub ends_by_ms: Option<u64>,
    /// Sessions of the allocated humans who have joined this worker. Before
    /// the match starts, the lobby re-queues these when the allocation ends
    /// (LR-32); a human who never came is not re-queued. Additive.
    #[serde(default, skip_serializing_if = "Vec::is_empty")]
    pub joined_sessions: Vec<String>,
    #[serde(default, skip_serializing_if = "Vec::is_empty")]
    pub released_sessions: Vec<String>,
}
impl Status {
    /// The match was played: it is running or ended with a winner.
    pub fn played(&self) -> bool {
        matches!(self.phase, Phase::Running | Phase::Finished)
    }
}
pub(crate) fn atomic_json(path: &Path, value: &impl Serialize) -> io::Result<()> {
    let bytes = serde_json::to_vec(value).map_err(io::Error::other)?;
    let tmp = path.with_extension("tmp");
    let mut options = fs::OpenOptions::new();
    options.write(true).create(true).truncate(true);
    #[cfg(unix)]
    {
        use std::os::unix::fs::OpenOptionsExt;
        options.mode(0o600);
    }
    let mut file = options.open(&tmp)?;
    file.write_all(&bytes)?;
    file.sync_all()?;
    fs::rename(tmp, path)?;
    if let Some(parent) = path.parent() {
        fs::File::open(parent)?.sync_all()?;
    }
    Ok(())
}
pub(crate) struct Worker {
    pub manifest: Manifest,
    pub directory: PathBuf,
    pub recovery: bool,
    pub origin_epoch: u64,
    pub aborted: bool,
    pub booted_at: Instant,
    pub last_status: Option<Instant>,
    pub terminal_at: Option<Instant>,
    /// An allocated human joined at least once. A worker nobody ever reached
    /// aborts early instead of holding its arena for the whole join deadline.
    pub saw_human: bool,
    pub released: Vec<String>,
    pub last_release_scan: Option<Instant>,
}
impl Worker {
    pub fn cancelled(&self) -> bool {
        self.directory.join("cancel.json").exists()
    }
}
impl ServerRuntime {
    pub(crate) fn allocated_team(&self, addr: SocketAddr, packet: &ClientPacket) -> Option<Team> {
        let worker = self.match_service.worker()?;
        let ClientPacket::Join {
            session_id: Some(session),
            ..
        } = packet
        else {
            return None;
        };
        let profile = self.career.backend.profile(addr)?;
        if self.career.backend.authenticated_session(addr).as_deref() != Some(session) {
            return None;
        }
        if worker.released.iter().any(|s| s == session) {
            return None;
        }
        worker.manifest.team(&profile.profile_id, session)
    }
    pub(crate) fn authorize_allocated_join(&self, addr: SocketAddr, packet: &ClientPacket) -> bool {
        if self.match_service.is_lobby() {
            return false;
        }
        let Some(worker) = self.match_service.worker() else {
            return true;
        };
        if worker.recovery || worker.aborted || self.allocated_team(addr, packet).is_none() {
            return false;
        }
        let ClientPacket::Join { session_id, .. } = packet else {
            return false;
        };
        if self.match_started_at.is_none() {
            return unix_ms() <= worker.manifest.join_deadline_ms && !worker.cancelled();
        }
        // No new gameplay identity can enter a frozen roster, even with a valid manifest.
        session_id.as_ref().is_some_and(|s| {
            self.world
                .players
                .values()
                .any(|p| p.joined && p.session_id.as_ref() == Some(s))
                || self
                    .world
                    .disconnected_sessions
                    .get(s)
                    .is_some_and(|p| p.player.joined)
        })
    }
    pub(crate) fn allocated_humans_ready(&self) -> bool {
        self.match_service.worker().is_none_or(|worker| {
            worker
                .manifest
                .humans
                .iter()
                .filter(|h| !worker.released.contains(&h.session_id))
                .all(|h| {
                    self.world.players.values().any(|p| {
                        p.joined
                            && !p.hero.identity.is_bot
                            && p.session_id.as_deref() == Some(h.session_id.as_str())
                            && p.career_profile
                                .as_ref()
                                .is_some_and(|p| p.profile_id == h.profile_id)
                    })
                })
        })
    }
}
#[cfg(test)]
mod tests {
    use super::*;
    use shared::map::Team;
    fn fixture() -> Manifest {
        Manifest {
            ranked_season_id: None,
            version: 1,
            allocation_id: "a".repeat(32),
            endpoint: "127.0.0.1:41000".into(),
            bind: "127.0.0.1:41000".into(),
            preference: MatchPreference::BotPractice,
            humans: vec![AllocatedHuman {
                profile_id: "b".repeat(64),
                session_id: "session-1".into(),
                team: shared::map::Team::Green,
            }],
            join_deadline_ms: 1,
            cohort: None,
        }
    }
    #[test]
    fn roster_rejects_duplicate_and_mismatched_identity() {
        let mut m = fixture();
        assert!(m.validate().is_ok());
        assert_eq!(m.team(&"b".repeat(64), "session-1"), Some(Team::Green));
        assert!(m.team(&"b".repeat(64), "other").is_none());
        m.humans.push(m.humans[0].clone());
        assert!(m.validate().is_err());
    }
    #[test]
    fn ranked_requires_full_roster() {
        let mut m = fixture();
        m.preference = MatchPreference::Ranked;
        assert!(m.validate().is_err());
    }

    /// LR-08: the queue, not the head count, picks the worker rules. Ten
    /// humans in Casual PvP play unrated practice rules; only Ranked is
    /// release (rated) rules.
    #[test]
    fn only_ranked_runs_the_rated_release_rules() {
        use crate::match_rules::MatchMode;
        let mut m = fixture();
        m.humans = (0..10_u8)
            .map(|i| AllocatedHuman {
                profile_id: format!("{i:064x}"),
                session_id: format!("session-{i}"),
                team: if i < 5 { Team::Green } else { Team::Blue },
            })
            .collect();
        m.preference = MatchPreference::Casual;
        assert_eq!(m.validate(), Ok(()));
        assert_eq!(m.match_mode(), MatchMode::Practice);
        m.preference = MatchPreference::Ranked;
        assert_eq!(m.validate(), Ok(()));
        assert_eq!(m.match_mode(), MatchMode::Release);
        m.humans.truncate(1);
        m.preference = MatchPreference::Casual;
        assert_eq!(m.match_mode(), MatchMode::Practice);
        m.preference = MatchPreference::BotPractice;
        assert_eq!(m.match_mode(), MatchMode::Practice);
    }
}

#[cfg(test)]
pub(crate) mod runtime_tests {
    use shared::wire::GameState;
    use std::net::{SocketAddr, UdpSocket};
    use std::time::{Duration, Instant};

    use shared::HeroClass;
    use shared::map::Team;
    use shared::wire::{ClientPacket, ServerPacket, default_character_choice};

    use super::*;
    use crate::entities::DisconnectedSession;
    use crate::match_rules::{MatchConfig, MatchMode};
    use crate::runtime::{PLAYER_TIMEOUT, ServerRuntime};
    use crate::snapshot::{SNAPSHOT_INTERVAL, build_players_snapshot};
    /// An allocated BotPractice worker for one authenticated player.
    pub(crate) fn fixture() -> (ServerRuntime, SocketAddr, ClientPacket) {
        let socket = UdpSocket::bind("127.0.0.1:0").unwrap();
        socket.set_nonblocking(true).unwrap();
        let mut rt = ServerRuntime::new(
            socket,
            MatchConfig {
                mode: MatchMode::Practice,
                team_size: 5,
            },
        );
        rt.career.backend = Box::new(crate::career_backend::MemoryCareer::test_backend(
            rt.server_epoch,
        ));
        let addr = "127.0.0.1:60200".parse().unwrap();
        let profile = shared::career::ProfileSummary::new("a".repeat(64), "Alice".into());
        rt.career
            .backend
            .test_authenticated(addr, profile.clone(), "seat-a");
        rt.match_service = crate::match_service::MatchService::Worker(Worker {
            manifest: Manifest {
                ranked_season_id: None,
                version: 1,
                allocation_id: "b".repeat(32),
                endpoint: "127.0.0.1:41000".into(),
                bind: "127.0.0.1:41000".into(),
                preference: MatchPreference::BotPractice,
                humans: vec![AllocatedHuman {
                    profile_id: profile.profile_id,
                    session_id: "seat-a".into(),
                    team: shared::map::Team::Blue,
                }],
                join_deadline_ms: unix_ms() + 180_000,
                cohort: None,
            },
            directory: std::env::temp_dir().join(format!(
                "omoba-allocation-test-{}-{}",
                std::process::id(),
                rt.server_epoch
            )),
            recovery: false,
            origin_epoch: 0,
            aborted: false,
            booted_at: Instant::now(),
            last_status: None,
            terminal_at: None,
            saw_human: false,
            released: Vec::new(),
            last_release_scan: None,
        });
        let join = ClientPacket::Join {
            handheld: Default::default(),
            prematch: false,
            team: Team::Green,
            character: default_character_choice(),
            hero_class: HeroClass::Mage,
            avatar: None,
            sprite_character: None,
            session_id: Some("seat-a".into()),
            passport_ticket: None,
        };
        (rt, addr, join)
    }

    #[test]
    fn casual_leave_releases_only_the_exact_profile_session_and_keeps_other_reserved_seats() {
        let (mut rt, member, _) = fixture();
        let outsider = "127.0.0.1:60309".parse().unwrap();
        rt.career.backend.test_authenticated(
            outsider,
            shared::career::ProfileSummary::new("c".repeat(64), "Other".into()),
            "seat-a",
        );
        if let crate::match_service::MatchService::Worker(worker) = &mut rt.match_service {
            worker.manifest.humans.push(AllocatedHuman {
                profile_id: "d".repeat(64),
                session_id: "seat-b".into(),
                team: Team::Blue,
            });
        }
        rt.leave_match(outsider, Instant::now());
        assert!(
            rt.match_service.worker().unwrap().released.is_empty(),
            "session collision must not release someone else's allocation"
        );
        rt.leave_match(member, Instant::now());
        let worker = rt.match_service.worker().unwrap();
        assert_eq!(worker.released, ["seat-a"]);
        assert!(
            !worker.aborted,
            "the other allocated player may still arrive"
        );
    }
    #[test]
    fn only_allocated_profile_and_session_can_cancel_an_unstarted_worker() {
        use ed25519_dalek::{Signer, SigningKey};
        use shared::career::{CareerAction, CareerRequest, authorized_signing_bytes};
        let (mut rt, member, _) = fixture();
        if let crate::match_service::MatchService::Worker(worker) = &mut rt.match_service {
            worker.manifest.preference = MatchPreference::Ranked;
        }
        let now = Instant::now();
        let directory = rt.match_service.worker().unwrap().directory.clone();
        fs::create_dir_all(&directory).unwrap();
        let cancellation = directory.join("cancel.json");
        assert!(!cancellation.exists());
        let outsider = "127.0.0.1:60301".parse().unwrap();
        rt.career.backend.test_authenticated(
            outsider,
            shared::career::ProfileSummary::new("c".repeat(64), "Other".into()),
            "other-seat",
        );
        let wrong_session = "127.0.0.1:60302".parse().unwrap();
        rt.career.backend.test_authenticated(
            wrong_session,
            shared::career::ProfileSummary::new("a".repeat(64), "Alice".into()),
            "wrong-seat",
        );
        let key = SigningKey::from_bytes(&[7; 32]);
        let request = || {
            let nonce = "b".repeat(64);
            let action = CareerAction::CancelQueue;
            let bytes = authorized_signing_bytes(rt.server_epoch, &nonce, 1, &action);
            let signature: String = key
                .sign(&bytes)
                .to_bytes()
                .iter()
                .map(|b| format!("{b:02x}"))
                .collect();
            CareerRequest::Authorized {
                session_nonce: nonce,
                sequence: 1,
                action,
                signature,
            }
        };
        let outsider_request = request();
        let wrong_request = request();
        let member_request = request();
        rt.handle_career_request(outsider, outsider_request, now);
        assert!(
            !cancellation.exists(),
            "foreign authenticated profile cancelled the worker"
        );
        rt.handle_career_request(wrong_session, wrong_request, now);
        assert!(
            !cancellation.exists(),
            "different session cancelled the frozen allocation"
        );
        rt.handle_career_request(member, member_request, now);
        assert!(
            cancellation.exists(),
            "allocated participant could not cancel formation"
        );
        fs::remove_dir_all(directory).unwrap();
    }

    #[test]
    fn gameplay_leave_cancels_only_its_unstarted_ranked_allocation_and_blocks_rejoin() {
        let (mut rt, member, join) = fixture();
        if let crate::match_service::MatchService::Worker(worker) = &mut rt.match_service {
            worker.manifest.preference = MatchPreference::Ranked;
        }
        let directory = rt.match_service.worker().unwrap().directory.clone();
        fs::create_dir_all(&directory).unwrap();
        let cancellation = directory.join("cancel.json");
        let now = Instant::now();
        let outsider = "127.0.0.1:60303".parse().unwrap();
        let wrong_session = "127.0.0.1:60304".parse().unwrap();
        rt.career.backend.test_authenticated(
            outsider,
            shared::career::ProfileSummary::new("c".repeat(64), "Other".into()),
            "seat-a",
        );
        rt.career.backend.test_authenticated(
            wrong_session,
            shared::career::ProfileSummary::new("a".repeat(64), "Alice".into()),
            "other-session",
        );
        for addr in [outsider, wrong_session] {
            rt.handle_packet(addr, ClientPacket::Leave, now);
            assert!(
                !cancellation.exists(),
                "a foreign profile/session cancelled the draft"
            );
            assert!(!rt.match_service.worker().unwrap().aborted);
        }
        rt.handle_packet(member, ClientPacket::Leave, now);
        rt.handle_packet(member, ClientPacket::Leave, now);
        let left: Vec<String> = serde_json::from_slice(&fs::read(cancellation).unwrap()).unwrap();
        assert_eq!(left, ["seat-a"]);
        assert!(rt.match_service.worker().unwrap().aborted);
        assert!(
            !rt.authorize_allocated_join(member, &join),
            "late Join revived a cancelled allocation"
        );
        fs::remove_dir_all(directory).unwrap();
    }

    #[test]
    fn gameplay_leave_does_not_cancel_a_started_ranked_worker() {
        let (mut rt, member, _) = fixture();
        if let crate::match_service::MatchService::Worker(worker) = &mut rt.match_service {
            worker.manifest.preference = MatchPreference::Ranked;
        }
        let directory = rt.match_service.worker().unwrap().directory.clone();
        fs::create_dir_all(&directory).unwrap();
        let now = Instant::now();
        rt.match_started_at = Some(now);
        rt.handle_packet(member, ClientPacket::Leave, now);
        assert!(!directory.join("cancel.json").exists());
        assert!(!rt.match_service.worker().unwrap().aborted);
        fs::remove_dir_all(directory).unwrap();
    }

    #[test]
    fn aborted_ranked_draft_repeats_return_views_without_simulating_for_leave_or_deadline() {
        for explicit_leave in [true, false] {
            let (mut rt, member, mut join) = fixture();
            rt.rules = crate::match_rules::MatchRules::from(MatchConfig {
                mode: MatchMode::Release,
                team_size: 5,
            });
            let survivor: SocketAddr = "127.0.0.1:60305".parse().unwrap();
            let other = shared::career::ProfileSummary::new("c".repeat(64), "Bob".into());
            rt.career
                .backend
                .test_authenticated(survivor, other.clone(), "seat-b");
            if let crate::match_service::MatchService::Worker(worker) = &mut rt.match_service {
                worker.manifest.preference = MatchPreference::Ranked;
                worker.manifest.humans.push(AllocatedHuman {
                    profile_id: other.profile_id,
                    session_id: "seat-b".into(),
                    team: Team::Green,
                });
            }
            if let ClientPacket::Join { prematch, .. } = &mut join {
                *prematch = true;
            }
            let mut other_join = join.clone();
            if let ClientPacket::Join { session_id, .. } = &mut other_join {
                *session_id = Some("seat-b".into());
            }
            let directory = rt.match_service.worker().unwrap().directory.clone();
            fs::create_dir_all(&directory).unwrap();
            let now = rt.clock.now();
            rt.handle_packet(member, join, now);
            rt.handle_packet(survivor, other_join, now);
            assert!(rt.world.players[&survivor].joined);
            if explicit_leave {
                rt.handle_packet(member, ClientPacket::Leave, now);
            } else {
                if let crate::match_service::MatchService::Worker(worker) = &mut rt.match_service {
                    worker.manifest.join_deadline_ms = 0;
                }
                rt.tick_match_service(now);
            }
            assert!(rt.match_service.worker().unwrap().aborted);
            let gold = rt.world.players[&survivor].economy.gold;
            let before = rt.snapshot_tick;
            for step in 1..=2 {
                rt.tick(now + Duration::from_millis(100 * step), 0.1);
                assert_eq!(
                    rt.world.players[&survivor].draft.error.as_deref(),
                    Some("allocation_cancelled_or_expired")
                );
                assert_eq!(rt.world.players[&survivor].economy.gold, gold);
                assert!(rt.match_started_at.is_none());
            }
            assert!(
                rt.snapshot_tick >= before + 2,
                "retired draft stopped publishing its return signal"
            );
            fs::remove_dir_all(directory).unwrap();
        }
    }

    #[test]
    fn allocated_practice_forces_draft_team_and_durable_start() {
        let (mut rt, addr, join) = fixture();
        let now = Instant::now();
        rt.handle_packet(addr, join, now);
        assert!(rt.world.players[&addr].joined);
        assert!(rt.world.players[&addr].draft.capable);
        assert_eq!(rt.world.players[&addr].hero.identity.team, Team::Blue);
        assert_eq!(
            rt.world
                .players
                .values()
                .filter(|p| p.hero.identity.is_bot)
                .count(),
            9
        );
        assert!(matches!(rt.world.game_state, GameState::Forming { .. }));
        assert!(!rt.begin_career_round(now));
        let allocation = rt.career_allocation_for_test().unwrap();
        assert_eq!(allocation.ruleset, "public-casual-v1");
        assert_eq!(allocation.unrated_reason.as_deref(), Some("allocated_bots"));
        assert!(!allocation.rated);
        assert_eq!(allocation.participants.len(), 10);
        rt.career.backend.test_ack_start(&allocation.result_id);
        assert!(
            !rt.begin_career_round(now),
            "gameplay activation also needs an ACK"
        );
        rt.career.backend.test_ack_gameplay(&allocation.result_id);
        assert!(rt.begin_career_round(now));
    }

    /// LR-08 acceptance: ten humans in Casual PvP are unrated (public casual,
    /// `casual_queue`, no bots); the same ten humans in Ranked are rated.
    #[test]
    fn ten_allocated_humans_are_rated_only_in_ranked() {
        for preference in [MatchPreference::Casual, MatchPreference::Ranked] {
            let humans: Vec<_> = (0..10_u8)
                .map(|i| AllocatedHuman {
                    profile_id: format!("{:064x}", u64::from(i) + 1),
                    session_id: format!("seat-{i}"),
                    team: if i % 2 == 0 { Team::Green } else { Team::Blue },
                })
                .collect();
            let manifest = Manifest {
                ranked_season_id: None,
                version: 1,
                allocation_id: "c".repeat(32),
                endpoint: "127.0.0.1:41000".into(),
                bind: "127.0.0.1:41000".into(),
                preference,
                humans: humans.clone(),
                join_deadline_ms: unix_ms() + 180_000,
                cohort: None,
            };
            assert_eq!(manifest.validate(), Ok(()));
            let socket = UdpSocket::bind("127.0.0.1:0").unwrap();
            socket.set_nonblocking(true).unwrap();
            let mut rt = ServerRuntime::new(
                socket,
                MatchConfig {
                    mode: manifest.match_mode(),
                    team_size: 5,
                },
            );
            rt.career.backend = Box::new(crate::career_backend::MemoryCareer::test_backend(
                rt.server_epoch,
            ));
            rt.match_service = crate::match_service::MatchService::Worker(Worker {
                manifest,
                directory: std::env::temp_dir().join(format!(
                    "omoba-allocation-test-{}-{}",
                    std::process::id(),
                    rt.server_epoch
                )),
                recovery: false,
                origin_epoch: 0,
                aborted: false,
                booted_at: Instant::now(),
                last_status: None,
                terminal_at: None,
                saw_human: false,
                released: Vec::new(),
                last_release_scan: None,
            });
            let now = Instant::now();
            for (i, human) in humans.iter().enumerate() {
                let addr: SocketAddr = format!("127.0.0.1:{}", 60400 + i).parse().unwrap();
                rt.career.backend.test_authenticated(
                    addr,
                    shared::career::ProfileSummary::new(
                        human.profile_id.clone(),
                        format!("Player {i}"),
                    ),
                    &human.session_id,
                );
                let join = ClientPacket::Join {
                    handheld: Default::default(),
                    prematch: false,
                    team: Team::Green,
                    character: default_character_choice(),
                    hero_class: HeroClass::Mage,
                    avatar: None,
                    sprite_character: None,
                    session_id: Some(human.session_id.clone()),
                    passport_ticket: None,
                };
                rt.handle_packet(addr, join, now);
            }
            assert!(rt.allocated_humans_ready(), "{preference:?}");
            assert!(!rt.begin_career_round(now), "waits for the durable start");
            let allocation = rt.career_allocation_for_test().unwrap();
            assert_eq!(allocation.participants.len(), 10);
            assert!(allocation.participants.iter().all(|p| !p.is_bot));
            match preference {
                MatchPreference::Casual => {
                    assert!(!allocation.rated);
                    assert_eq!(allocation.ruleset, "public-casual-v1");
                    assert_eq!(allocation.unrated_reason.as_deref(), Some("casual_queue"));
                }
                _ => {
                    assert!(allocation.rated, "{:?}", allocation.unrated_reason);
                    assert_eq!(allocation.ruleset, crate::career_runtime::RATED_RULESET);
                }
            }
        }
    }

    #[test]
    fn allocated_worker_bots_play_elite_whatever_level_is_requested() {
        use shared::bot_profile::BotDifficulty;
        let (mut rt, addr, join) = fixture();
        let now = Instant::now();
        // Online bots are always Elite: a worker never takes a practice level.
        rt.set_bot_difficulty(BotDifficulty::Recruit);
        rt.handle_packet(addr, join, now);
        for team in [Team::Green, Team::Blue] {
            assert_eq!(rt.bots.difficulty(team), BotDifficulty::Elite);
        }
        let profiles: Vec<_> = rt
            .world
            .players
            .iter()
            .filter(|(_, p)| p.hero.identity.is_bot)
            .map(|(bot, _)| rt.bots.profile(*bot))
            .collect();
        assert_eq!(profiles.len(), 9);
        assert!(
            profiles
                .iter()
                .all(|p| *p == Some(crate::bots::BotProfile::ELITE)),
            "{profiles:?}"
        );
    }

    #[test]
    fn allocated_practice_refuses_debug_toggles_after_the_durable_start() {
        let (mut rt, addr, join) = fixture();
        let now = Instant::now();
        rt.handle_packet(addr, join, now);
        assert!(!rt.begin_career_round(now));
        let allocation = rt.career_allocation_for_test().unwrap();
        assert_eq!(allocation.ruleset, "public-casual-v1");
        rt.career.backend.test_ack_start(&allocation.result_id);
        assert!(
            !rt.begin_career_round(now),
            "gameplay activation also needs an ACK"
        );
        rt.career.backend.test_ack_gameplay(&allocation.result_id);
        assert!(rt.begin_career_round(now));
        assert!(
            rt.rules.debug_commands,
            "worker practice keeps Practice rules"
        );
        assert_eq!(
            rt.debug_access(),
            shared::debug::DebugAccess::default(),
            "a worker round refuses the whole debug family"
        );

        rt.handle_packet(addr, ClientPacket::SetGodMode { enabled: true }, now);
        rt.handle_packet(addr, ClientPacket::SetSpeedBoost { enabled: true }, now);
        let player = &rt.world.players[&addr];
        assert!(
            !player.modifiers.god_mode && !player.modifiers.infinite_resource,
            "god mode must not ride into a durable public-casual result"
        );
        assert_eq!(player.modifiers.move_speed_mult, 1.0);
    }
    #[test]
    fn strangers_cannot_enter_and_original_identity_reclaims_its_frozen_seat() {
        let (mut rt, addr, join) = fixture();
        let now = Instant::now();
        rt.handle_packet(addr, join.clone(), now);
        let id = rt.world.players[&addr].hero.identity.id;
        rt.begin_career_round(now);
        let allocation = rt.career_allocation_for_test().unwrap();
        rt.career.backend.test_ack_start(&allocation.result_id);
        assert!(
            !rt.begin_career_round(now),
            "gameplay activation also needs an ACK"
        );
        rt.career.backend.test_ack_gameplay(&allocation.result_id);
        assert!(rt.begin_career_round(now));
        rt.world.game_state = GameState::Running;
        rt.match_started_at = Some(now);
        let outsider: SocketAddr = "127.0.0.1:60201".parse().unwrap();
        rt.career.backend.test_authenticated(
            outsider,
            shared::career::ProfileSummary::new("c".repeat(64), "Other".into()),
            "other-seat",
        );
        let mut foreign = join.clone();
        if let ClientPacket::Join { session_id, .. } = &mut foreign {
            *session_id = Some("other-seat".into());
        }
        rt.handle_packet(outsider, foreign, now);
        assert!(!rt.world.players[&outsider].joined);
        let original = rt.world.players.remove(&addr).unwrap();
        rt.world.disconnected_sessions.insert(
            "seat-a".into(),
            DisconnectedSession {
                player: original,
                disconnected_at: now,
            },
        );
        rt.career.backend.forget(addr);
        let reconnect: SocketAddr = "127.0.0.1:60202".parse().unwrap();
        rt.career.backend.test_authenticated(
            reconnect,
            shared::career::ProfileSummary::new("a".repeat(64), "Alice".into()),
            "seat-a",
        );
        rt.handle_packet(reconnect, join, now);
        assert!(rt.world.players[&reconnect].joined);
        assert_eq!(rt.world.players[&reconnect].hero.identity.id, id);
        assert_eq!(rt.world.players[&reconnect].hero.identity.team, Team::Blue);
        assert_eq!(
            rt.world
                .players
                .values()
                .filter(|p| p.hero.identity.is_bot)
                .count(),
            9
        );
    }
    #[test]
    fn empty_allocated_worker_preserves_the_full_reconnect_window() {
        let (mut rt, addr, join) = fixture();
        let now = Instant::now();
        rt.handle_packet(addr, join, now);
        rt.begin_career_round(now);
        let result = rt.career_allocation_for_test().unwrap();
        rt.career.backend.test_ack_start(&result.result_id);
        assert!(
            !rt.begin_career_round(now),
            "gameplay activation also needs an ACK"
        );
        rt.career.backend.test_ack_gameplay(&result.result_id);
        assert!(rt.begin_career_round(now));
        rt.world.game_state = GameState::Running;
        rt.match_started_at = Some(now);
        rt.maintain_roster(now + PLAYER_TIMEOUT + Duration::from_secs(1));
        rt.maintain_roster(now + PLAYER_TIMEOUT + Duration::from_secs(20));
        assert!(
            rt.world
                .players
                .iter()
                .any(|(addr, p)| crate::bots::is_bot_address(*addr)
                    && p.session_id.as_deref() == Some("seat-a"))
        );
        assert!(!rt.match_service.worker().unwrap().aborted);
        assert_eq!(rt.world.game_state, GameState::Running);
    }
    #[test]
    fn running_allocated_match_reclaims_same_hero_after_the_menu_retry_budget() {
        use crate::balance::SESSION_RECLAIM_WINDOW;
        for elapsed in [
            Duration::from_secs(120),
            SESSION_RECLAIM_WINDOW + Duration::from_secs(2),
        ] {
            let (mut rt, addr, join) = fixture();
            let now = Instant::now();
            rt.handle_packet(addr, join.clone(), now);
            let id = rt.world.players[&addr].hero.identity.id;
            rt.begin_career_round(now);
            let result = rt.career_allocation_for_test().unwrap();
            rt.career.backend.test_ack_start(&result.result_id);
            assert!(
                !rt.begin_career_round(now),
                "gameplay activation also needs an ACK"
            );
            rt.career.backend.test_ack_gameplay(&result.result_id);
            assert!(rt.begin_career_round(now));
            rt.world.game_state = GameState::Running;
            rt.match_started_at = Some(now);
            rt.world.players.get_mut(&addr).unwrap().hero.hp = 47.0;
            common::recall::start(rt.world.players.get_mut(&addr).unwrap(), now);
            rt.maintain_roster(now + PLAYER_TIMEOUT + Duration::from_millis(1));
            let resume = now + PLAYER_TIMEOUT + elapsed;
            let new_addr: SocketAddr = "127.0.0.1:60209".parse().unwrap();
            rt.career.backend.test_authenticated(
                new_addr,
                shared::career::ProfileSummary::new("a".repeat(64), "Alice".into()),
                "seat-a",
            );
            rt.handle_packet(new_addr, join, resume);
            let player = &rt.world.players[&new_addr];
            assert!(player.joined);
            assert_eq!(player.hero.identity.id, id);
            assert_eq!(player.hero.hp, 47.0);
            assert_eq!(common::recall::remaining(player, resume), 0.0);
            assert!(!rt.match_service.worker().unwrap().aborted);
            assert!(rt.world.disconnected_sessions.is_empty());
            assert!(
                rt.world
                    .players
                    .iter()
                    .all(|(addr, player)| player.hero.identity.id != id
                        || !crate::bots::is_bot_address(*addr))
            );
        }
    }

    #[test]
    fn deliberate_last_leave_keeps_running_allocated_hero_live() {
        let (mut rt, addr, join) = fixture();
        let now = Instant::now();
        rt.handle_packet(addr, join, now);
        rt.begin_career_round(now);
        let result = rt.career_allocation_for_test().unwrap();
        rt.career.backend.test_ack_start(&result.result_id);
        assert!(
            !rt.begin_career_round(now),
            "gameplay activation also needs an ACK"
        );
        rt.career.backend.test_ack_gameplay(&result.result_id);
        assert!(rt.begin_career_round(now));
        rt.world.game_state = GameState::Running;
        rt.match_started_at = Some(now);
        rt.handle_packet(addr, ClientPacket::Leave, now);
        rt.maintain_roster(now);
        assert!(rt.world.disconnected_sessions.is_empty());
        rt.maintain_roster(now + crate::balance::EMPTY_ROSTER_GRACE);
        assert!(!rt.match_service.worker().unwrap().aborted);
        assert_eq!(rt.world.game_state, GameState::Running);
        assert!(
            rt.world
                .players
                .iter()
                .any(|(addr, player)| !player.hero.identity.is_bot
                    && crate::bots::is_bot_address(*addr)
                    && rt.bots.kind(*addr).is_some())
        );
    }

    /// The production return-path admission (probe, challenge, proof) for
    /// `addr`, then the Hello it yields, as the receive loop dispatches it.
    fn admit_public_endpoint(rt: &mut ServerRuntime, addr: SocketAddr, now: Instant) {
        use shared::public_transport::{
            PROBE_PADDING_BYTES, PublicClientDatagram, PublicServerDatagram,
        };
        let probe = serde_json::to_vec(&PublicClientDatagram::TransportProbe {
            protocol_version: shared::protocol::PROTOCOL_VERSION,
            client_nonce: "a".repeat(32),
            padding: "0".repeat(PROBE_PADDING_BYTES),
        })
        .unwrap();
        let (epoch, match_id) = (rt.server_epoch, rt.match_id);
        let crate::public_transport::Decision::Reply(challenge) = rt
            .public_transport
            .receive(addr, &probe, epoch, match_id, false, None, now)
        else {
            panic!("missing path challenge");
        };
        let PublicServerDatagram::TransportChallenge { path_nonce, .. } =
            serde_json::from_slice(&challenge).unwrap()
        else {
            panic!("a transport challenge is expected")
        };
        let proof = serde_json::to_vec(&PublicClientDatagram::TransportProof {
            server_epoch: epoch,
            path_nonce,
        })
        .unwrap();
        let crate::public_transport::Decision::Dispatch(hello) = rt
            .public_transport
            .receive(addr, &proof, epoch, match_id, false, None, now)
        else {
            panic!("path proof rejected");
        };
        rt.handle_packet(addr, hello, now);
        assert!(rt.public_transport.validated(addr, now));
    }

    #[test]
    fn detached_seat_gets_no_social_datagrams_and_reclaim_resumes_the_stream() {
        use crate::runtime::ports::MemoryTransport;
        use shared::social::{SocialCommand, SocialRequest};
        let (mut rt, addr, join) = fixture();
        let transport = MemoryTransport::new("127.0.0.1:41000".parse().unwrap());
        rt.transport = Box::new(transport.clone());
        let destinations = |transport: &MemoryTransport| -> Vec<SocketAddr> {
            transport
                .take_outbound()
                .into_iter()
                .map(|(to, _)| to)
                .collect()
        };
        let now = Instant::now();
        admit_public_endpoint(&mut rt, addr, now);
        rt.handle_packet(addr, join.clone(), now);
        let id = rt.world.players[&addr].hero.identity.id;
        rt.begin_career_round(now);
        let result = rt.career_allocation_for_test().unwrap();
        rt.career.backend.test_ack_start(&result.result_id);
        assert!(
            !rt.begin_career_round(now),
            "gameplay activation also needs an ACK"
        );
        rt.career.backend.test_ack_gameplay(&result.result_id);
        assert!(rt.begin_career_round(now));
        rt.world.game_state = GameState::Running;
        rt.match_started_at = Some(now);
        let subscribe = SocialRequest {
            request_id: 1,
            server_epoch: rt.server_epoch,
            match_id: rt.match_id,
            session_id: "seat-a".into(),
            command: SocialCommand::Subscribe,
        };
        rt.handle_social_request(addr, subscribe, true, now);
        assert!(rt.social.subscribed(id));
        transport.take_outbound();
        rt.send_social_views(now);
        let sent = destinations(&transport);
        assert!(!sent.is_empty() && sent.iter().all(|to| *to == addr));

        // Human -> bot handover: the live hero moves to an internal actor
        // address (`[::]:N`) that a bot drives for the rest of the match.
        rt.handle_packet(addr, ClientPacket::Leave, now);
        let (&detached, seat) = rt
            .world
            .players
            .iter()
            .find(|(_, p)| p.hero.identity.id == id)
            .unwrap();
        assert!(crate::bots::is_bot_address(detached));
        assert!(seat.joined && seat.framed_snapshots && !seat.hero.identity.is_bot);
        assert!(rt.bots.kind(detached).is_some());
        assert!(
            rt.social.subscribed(id),
            "the subscription follows the identity, not the endpoint"
        );
        let mut at = now;
        for _ in 0..8 {
            at += Duration::from_millis(250);
            rt.send_social_views(at);
        }
        let sent = destinations(&transport);
        assert!(
            sent.is_empty(),
            "neither the internal actor nor the departed endpoint gets Social datagrams: {sent:?}"
        );

        // Reclaim from a new endpoint: the identity's stream resumes there.
        let reconnect: SocketAddr = "127.0.0.1:60411".parse().unwrap();
        rt.career.backend.test_authenticated(
            reconnect,
            shared::career::ProfileSummary::new("a".repeat(64), "Alice".into()),
            "seat-a",
        );
        admit_public_endpoint(&mut rt, reconnect, at);
        rt.handle_packet(reconnect, join, at);
        assert_eq!(rt.world.players[&reconnect].hero.identity.id, id);
        assert!(!rt.world.players.contains_key(&detached));
        transport.take_outbound();
        at += Duration::from_millis(250);
        rt.send_social_views(at);
        let sent = destinations(&transport);
        assert!(!sent.is_empty() && sent.iter().all(|to| *to == reconnect));
    }

    #[test]
    fn retained_human_survives_account_polling_and_reclaims_after_empty_grace() {
        for deliberate_leave in [false, true] {
            let (mut rt, addr, join) = fixture();
            let now = Instant::now();
            rt.handle_packet(addr, join.clone(), now);
            let id = rt.world.players[&addr].hero.identity.id;
            rt.begin_career_round(now);
            let result = rt.career_allocation_for_test().unwrap();
            rt.career.backend.test_ack_start(&result.result_id);
            assert!(
                !rt.begin_career_round(now),
                "gameplay activation also needs an ACK"
            );
            rt.career.backend.test_ack_gameplay(&result.result_id);
            assert!(rt.begin_career_round(now));
            rt.world.game_state = GameState::Running;
            rt.match_started_at = Some(now);
            let detached_at = now + PLAYER_TIMEOUT + Duration::from_secs(1);
            if deliberate_leave {
                rt.handle_packet(addr, ClientPacket::Leave, now);
            }
            rt.maintain_roster(detached_at);
            rt.poll_career(detached_at);
            let later = detached_at + crate::balance::EMPTY_ROSTER_GRACE + Duration::from_secs(20);
            rt.maintain_roster(later);
            rt.poll_career(later);
            let retained = rt
                .world
                .players
                .values()
                .find(|p| p.hero.identity.id == id)
                .unwrap();
            assert!(
                retained.joined,
                "career polling must preserve the retained human"
            );
            assert!(!retained.hero.identity.is_bot);
            assert_eq!(rt.world.game_state, GameState::Running);
            let reconnect: SocketAddr = "127.0.0.1:60409".parse().unwrap();
            rt.career.backend.test_authenticated(
                reconnect,
                shared::career::ProfileSummary::new("a".repeat(64), "Alice".into()),
                "seat-a",
            );
            rt.handle_packet(reconnect, join, later);
            rt.poll_career(later);
            assert!(rt.world.players[&reconnect].joined);
            assert_eq!(rt.world.players[&reconnect].hero.identity.id, id);
            assert!(rt.takeover_view(reconnect).is_empty());
        }
    }

    #[test]
    fn account_polling_still_invalidates_unregistered_or_changed_retained_identities() {
        for altered in [0, 1, 2] {
            let (mut rt, addr, join) = fixture();
            let now = Instant::now();
            rt.handle_packet(addr, join, now);
            rt.world.game_state = GameState::Running;
            rt.match_started_at = Some(now);
            let target = if altered == 0 {
                rt.career.backend.forget(addr);
                addr
            } else {
                assert!(rt.detach_running_seat(addr, now));
                let target = *rt
                    .world
                    .players
                    .iter()
                    .find(|(_, p)| {
                        !p.hero.identity.is_bot && p.session_id.as_deref() == Some("seat-a")
                    })
                    .unwrap()
                    .0;
                let player = rt.world.players.get_mut(&target).unwrap();
                if altered == 1 {
                    player.session_id = Some("wrong-session".into());
                } else {
                    player.hero.identity.id += 1000;
                }
                target
            };
            rt.poll_career(now);
            assert!(!rt.world.players[&target].joined);
        }
    }

    #[test]
    fn takeover_requires_authenticated_same_team_current_generation_and_restores_manual() {
        use shared::match_service::TakeoverPolicy;
        let (mut rt, alice, join) = fixture();
        let now = Instant::now();
        let bob: SocketAddr = "127.0.0.1:60312".parse().unwrap();
        let eve: SocketAddr = "127.0.0.1:60313".parse().unwrap();
        for (addr, session, profile, team) in [
            (bob, "bob", "c".repeat(64), Team::Blue),
            (eve, "eve", "d".repeat(64), Team::Green),
        ] {
            let profile = shared::career::ProfileSummary::new(profile, session.into());
            if let crate::match_service::MatchService::Worker(worker) = &mut rt.match_service {
                worker.manifest.preference = MatchPreference::Casual;
                worker.manifest.humans.push(AllocatedHuman {
                    profile_id: profile.profile_id.clone(),
                    session_id: session.into(),
                    team,
                });
            }
            rt.career.backend.test_authenticated(addr, profile, session);
            let mut request = join.clone();
            if let ClientPacket::Join { session_id, .. } = &mut request {
                *session_id = Some(session.into());
            }
            rt.handle_packet(addr, request, now);
        }
        rt.handle_packet(alice, join.clone(), now);
        rt.begin_career_round(now);
        let result = rt.career_allocation_for_test().unwrap();
        rt.career.backend.test_ack_start(&result.result_id);
        assert!(
            !rt.begin_career_round(now),
            "gameplay activation also needs an ACK"
        );
        rt.career.backend.test_ack_gameplay(&result.result_id);
        assert!(rt.begin_career_round(now));
        rt.world.game_state = GameState::Running;
        rt.match_started_at = Some(now);
        let original_id = rt.world.players[&alice].hero.identity.id;
        rt.handle_packet(alice, ClientPacket::Leave, now);
        let seat = rt.takeover_view(bob).pop().unwrap();
        assert_eq!(seat.policy, TakeoverPolicy::Bot);
        assert_eq!(seat.eligible_voters, 1);
        assert!(rt.takeover_view(eve).is_empty());
        let vote = ClientPacket::TakeoverVote {
            server_epoch: rt.server_epoch,
            match_id: rt.match_id,
            player_id: seat.player_id,
            generation: seat.generation,
            policy: TakeoverPolicy::Idle,
        };
        rt.handle_packet(eve, vote.clone(), now);
        assert_eq!(rt.takeover_view(bob)[0].policy, TakeoverPolicy::Bot);
        rt.handle_packet(bob, vote.clone(), now);
        assert_eq!(rt.takeover_view(bob)[0].policy, TakeoverPolicy::Idle);
        let detached = *rt
            .world
            .players
            .iter()
            .find(|(_, p)| p.hero.identity.id == original_id)
            .unwrap()
            .0;
        assert!(rt.bots.kind(detached).is_none());
        rt.career.backend.test_authenticated(
            alice,
            shared::career::ProfileSummary::new("a".repeat(64), "Alice".into()),
            "seat-a",
        );
        rt.handle_packet(alice, join, now);
        assert_eq!(rt.world.players[&alice].hero.identity.id, original_id);
        assert!(rt.takeover_view(bob).is_empty());
        assert!(rt.bots.kind(detached).is_none());
        rt.handle_packet(alice, ClientPacket::Leave, now);
        rt.handle_packet(bob, vote, now);
        assert_eq!(
            rt.takeover_view(bob)[0].policy,
            TakeoverPolicy::Bot,
            "a delayed old vote cannot idle a subsequent disconnection"
        );
        rt.career.backend.forget(bob);
        assert!(rt.takeover_view(bob).is_empty());
    }

    #[test]
    fn fresh_quick_handoff_after_thirty_seconds_enters_draft_without_terminal_result() {
        let (mut rt, addr, join) = fixture();
        let now = Instant::now() + Duration::from_secs(30);
        if let crate::match_service::MatchService::Worker(worker) = &mut rt.match_service {
            worker.manifest.preference = MatchPreference::Casual;
        }
        rt.maintain_roster(now);
        rt.career.backend.test_authenticated(
            addr,
            shared::career::ProfileSummary::new("a".repeat(64), "Alice".into()),
            "seat-a",
        );
        rt.handle_packet(addr, join, now);
        rt.tick_prematch(now);
        assert!(rt.world.players[&addr].joined);
        assert_eq!(
            crate::prematch::snapshot(
                &rt.prematch,
                &rt.world.players,
                &rt.world.players[&addr],
                rt.rules,
                now
            )
            .unwrap()
            .phase,
            shared::prematch::PrematchPhase::Draft
        );
        assert!(rt.career_view(addr, now).last_result.is_none());
        assert!(!rt.match_service.worker().unwrap().aborted);
    }

    #[test]
    fn real_signed_udp_restart_reclaims_live_allocated_hero_after_three_minutes() {
        use ed25519_dalek::{Signer, SigningKey};
        use shared::public_transport::{
            PublicClientDatagram, PublicServerDatagram, SignedCommand, hex,
        };
        fn deliver(rt: &mut ServerRuntime, client: &UdpSocket, packet: &PublicClientDatagram) {
            client
                .send_to(
                    &serde_json::to_vec(packet).unwrap(),
                    rt.transport.local_addr().unwrap(),
                )
                .unwrap();
            let deadline = Instant::now() + Duration::from_secs(2);
            while rt.transport.peek(&mut [0; 1]).is_err() {
                assert!(Instant::now() < deadline, "UDP delivery timed out");
                std::thread::sleep(Duration::from_millis(1));
            }
            rt.receive_packets();
        }
        fn join_over_udp(rt: &mut ServerRuntime, client: &UdpSocket, join: &ClientPacket) {
            deliver(
                rt,
                client,
                &PublicClientDatagram::TransportProbe {
                    protocol_version: shared::protocol::PROTOCOL_VERSION,
                    client_nonce: "a".repeat(32),
                    padding: "0".repeat(384),
                },
            );
            let mut buffer = [0; 4096];
            let (len, _) = client.recv_from(&mut buffer).unwrap();
            let PublicServerDatagram::TransportChallenge { path_nonce, .. } =
                serde_json::from_slice(&buffer[..len]).unwrap()
            else {
                panic!("a transport challenge is expected")
            };
            deliver(
                rt,
                client,
                &PublicClientDatagram::TransportProof {
                    server_epoch: rt.server_epoch,
                    path_nonce: path_nonce.clone(),
                },
            );
            let addr = client.local_addr().unwrap();
            // Account storage is the test port; all gameplay traverses the real
            // UDP socket, path proof and production Ed25519 envelope gate.
            rt.career.backend.test_authenticated(
                addr,
                shared::career::ProfileSummary::new("a".repeat(64), "Alice".into()),
                "seat-a",
            );
            let principal = rt.career.backend.gameplay_principal(addr).unwrap();
            let mut command = SignedCommand {
                server_epoch: rt.server_epoch,
                match_id: rt.match_id,
                session_id: principal.session_id,
                session_nonce: principal.session_nonce,
                path_nonce,
                sequence: 1,
                payload: serde_json::to_string(join).unwrap(),
                signature: String::new(),
            };
            command.signature = hex(&SigningKey::from_bytes(&[7; 32])
                .sign(&command.signing_bytes())
                .to_bytes());
            deliver(rt, client, &PublicClientDatagram::SignedCommand { command });
        }
        let (mut rt, _, join) = fixture();
        let clock = crate::runtime::ports::ManualClock::new(Instant::now());
        rt.clock = Box::new(clock.clone());
        let client = UdpSocket::bind("127.0.0.1:0").unwrap();
        client
            .set_read_timeout(Some(Duration::from_secs(2)))
            .unwrap();
        join_over_udp(&mut rt, &client, &join);
        let addr = client.local_addr().unwrap();
        let now = rt.clock.now();
        let id = rt.world.players[&addr].hero.identity.id;
        rt.begin_career_round(now);
        let result = rt.career_allocation_for_test().unwrap();
        rt.career.backend.test_ack_start(&result.result_id);
        assert!(
            !rt.begin_career_round(now),
            "gameplay activation also needs an ACK"
        );
        rt.career.backend.test_ack_gameplay(&result.result_id);
        assert!(rt.begin_career_round(now));
        rt.world.game_state = GameState::Running;
        rt.match_started_at = Some(now);
        rt.world.players.get_mut(&addr).unwrap().economy.gold = 1234;
        drop(client); // Process exit: no Leave datagram is required.
        let later = clock.advance(Duration::from_secs(240));
        rt.tick(later, 0.1);
        assert!(
            rt.world.match_elapsed_secs > 0.0,
            "simulation continues without a connected human"
        );
        assert!(!rt.match_service.worker().unwrap().aborted);
        let detached = *rt
            .world
            .players
            .iter()
            .find(|(_, p)| p.hero.identity.id == id)
            .unwrap()
            .0;
        assert!(rt.bots.kind(detached).is_some());
        let retained_gold = rt.world.players[&detached].economy.gold;
        let request_id = rt.world.players[&detached].economy.basic_attack_request_id + 1;
        // The same shared handler used by AI refreshes last_seen, even when a
        // previously selected target has disappeared. It must not block its owner.
        common::basic_attack::handle_basic_attack_request(
            &mut rt.world,
            detached,
            shared::wire::TargetId {
                kind: shared::wire::TargetKind::Player,
                id: u64::MAX,
            },
            request_id,
            later,
        );
        assert_eq!(rt.world.players[&detached].last_seen, later);
        let restarted = UdpSocket::bind("127.0.0.1:0").unwrap();
        restarted
            .set_read_timeout(Some(Duration::from_secs(2)))
            .unwrap();
        join_over_udp(&mut rt, &restarted, &join);
        let restored = &rt.world.players[&restarted.local_addr().unwrap()];
        assert!(restored.joined);
        assert_eq!(restored.hero.identity.id, id);
        assert_eq!(restored.hero.identity.hero_class, HeroClass::Mage);
        assert_eq!(restored.economy.gold, retained_gold);
        assert!(!restored.hero.identity.is_bot);
        assert!(!rt.world.players.contains_key(&detached));
        assert!(rt.bots.kind(detached).is_none());
        assert_eq!(rt.world.game_state, GameState::Running);
    }

    #[test]
    fn aborted_worker_never_reopens_its_retained_roster() {
        let (mut rt, addr, join) = fixture();
        let now = Instant::now();
        rt.handle_packet(addr, join.clone(), now);
        rt.match_started_at = Some(now);
        if let crate::match_service::MatchService::Worker(worker) = &mut rt.match_service {
            worker.aborted = true;
        }
        assert!(!rt.authorize_allocated_join(addr, &join));
    }

    #[test]
    fn saved_worker_repeats_victory_udp_snapshots_after_first_frame_is_lost() {
        use shared::public_transport::{PublicClientDatagram, PublicServerDatagram};
        let (mut rt, _, join) = fixture();
        let client = UdpSocket::bind("127.0.0.1:0").unwrap();
        client
            .set_read_timeout(Some(Duration::from_secs(1)))
            .unwrap();
        let addr = client.local_addr().unwrap();
        let now = Instant::now();
        // Establish real public return-path state so the production snapshot
        // admission filter is exercised, rather than bypassed by test flags.
        let probe = serde_json::to_vec(&PublicClientDatagram::TransportProbe {
            protocol_version: shared::protocol::PROTOCOL_VERSION,
            client_nonce: "a".repeat(32),
            padding: "0".repeat(384),
        })
        .unwrap();
        let reply = rt.public_transport.receive(
            addr,
            &probe,
            rt.server_epoch,
            rt.match_id,
            false,
            None,
            now,
        );
        let crate::public_transport::Decision::Reply(bytes) = reply else {
            panic!("missing path challenge");
        };
        let PublicServerDatagram::TransportChallenge { path_nonce, .. } =
            serde_json::from_slice(&bytes).unwrap()
        else {
            panic!("a transport challenge is expected")
        };
        let proof = serde_json::to_vec(&PublicClientDatagram::TransportProof {
            server_epoch: rt.server_epoch,
            path_nonce,
        })
        .unwrap();
        let reply = rt.public_transport.receive(
            addr,
            &proof,
            rt.server_epoch,
            rt.match_id,
            false,
            None,
            now,
        );
        let crate::public_transport::Decision::Dispatch(hello) = reply else {
            panic!("path proof rejected");
        };
        rt.handle_packet(addr, hello, now);
        rt.career.backend.test_authenticated(
            addr,
            shared::career::ProfileSummary::new("a".repeat(64), "Alice".into()),
            "seat-a",
        );
        rt.handle_packet(addr, join, now);
        assert!(!rt.begin_career_round(now));
        let allocation = rt.career_allocation_for_test().unwrap();
        rt.career.backend.test_ack_start(&allocation.result_id);
        assert!(
            !rt.begin_career_round(now),
            "gameplay activation also needs an ACK"
        );
        rt.career.backend.test_ack_gameplay(&allocation.result_id);
        assert!(rt.begin_career_round(now));
        rt.world.game_state = GameState::Running;
        rt.match_started_at = Some(now);
        let epoch = rt.server_epoch;
        let match_id = rt.match_id;
        rt.world.game_state = GameState::Victory { winner: Team::Blue };
        rt.last_snapshot_at = now - SNAPSHOT_INTERVAL;
        rt.tick(now, 0.0);

        let mut assembler = shared::transport::SnapshotAssembler::default();
        let read_snapshot = |assembler: &mut shared::transport::SnapshotAssembler| {
            let mut buffer = vec![0; 65_536];
            loop {
                let (len, _) = client
                    .recv_from(&mut buffer)
                    .expect("worker stopped repeating terminal snapshots");
                if let Some(bytes) = assembler.push(&buffer[..len], Instant::now()).unwrap() {
                    let packet: ServerPacket = serde_json::from_slice(&bytes).unwrap();
                    if let ServerPacket::Snapshot { .. } = packet {
                        break packet;
                    }
                }
            }
        };
        // Deliberately discard the first Victory frame, as if UDP lost it.
        assert!(matches!(
            read_snapshot(&mut assembler),
            ServerPacket::Snapshot {
                game_state: GameState::Victory { winner: Team::Blue },
                ..
            }
        ));
        let mut saved = rt.career_allocation_for_test().unwrap();
        saved.saved = true;
        rt.career.backend.test_ack_settle(saved);
        rt.poll_career(now);
        rt.tick_match_service(now);
        assert!(rt.match_service.worker().unwrap().terminal_at.is_some());
        let frozen_players =
            serde_json::to_value(build_players_snapshot(&rt.world, None, now)).unwrap();
        let frozen_minions = rt.world.minions.len();
        let frozen_projectiles = rt.world.projectiles.len();
        for millis in [100, 500, 1000] {
            let later = now + Duration::from_millis(millis);
            rt.last_snapshot_at = later - SNAPSHOT_INTERVAL;
            rt.tick(later, 5.0);
            let packet = read_snapshot(&mut assembler);
            let ServerPacket::Snapshot {
                meta,
                game_state,
                players,
                scoreboard,
                debug_access,
                match_mode,
                ..
            } = packet
            else {
                unreachable!()
            };
            assert_eq!(game_state, GameState::Victory { winner: Team::Blue });
            // Step 11f: a worker round reports "practice" but accepts no
            // debug command, and says so to the joined player.
            assert_eq!(match_mode, "practice");
            assert_eq!(debug_access, Some(shared::debug::DebugAccess::default()));
            assert_eq!(meta.server_epoch, epoch);
            assert_eq!(meta.match_id, match_id);
            assert_eq!(players.len(), 5, "victory retains team fog");
            assert!(players.iter().all(|p| p.team == Team::Blue));
            assert_eq!(scoreboard.unwrap().players.len(), 10);
            assert_eq!(
                serde_json::to_value(build_players_snapshot(&rt.world, None, later)).unwrap(),
                frozen_players
            );
            assert_eq!(rt.world.minions.len(), frozen_minions);
            assert_eq!(rt.world.projectiles.len(), frozen_projectiles);
            assert_eq!(
                rt.career_allocation_for_test().unwrap().outcome,
                shared::career::MatchOutcome::Completed
            );
            assert!(rt.career_allocation_for_test().unwrap().saved);
            assert!(!rt.match_service.worker().unwrap().aborted);
        }
    }

    #[test]
    fn allocated_worker_never_restarts_into_a_second_world() {
        let (mut rt, addr, join) = fixture();
        let now = Instant::now();
        rt.handle_packet(addr, join, now);
        let epoch = rt.server_epoch;
        let match_id = rt.match_id;
        rt.restart_round(now);
        assert_eq!(rt.server_epoch, epoch);
        assert_eq!(rt.match_id, match_id);
        assert!(rt.match_service.worker().unwrap().aborted);
    }

    /// LR-32: a worker no allocated human ever reached frees its arena 60 s
    /// after boot instead of holding it for the whole join deadline; one a
    /// human did reach keeps waiting for the rest.
    #[test]
    fn a_worker_nobody_reached_aborts_a_minute_after_boot() {
        let (mut rt, _addr, _join) = fixture();
        let directory = rt.match_service.worker().unwrap().directory.clone();
        fs::create_dir_all(&directory).unwrap();
        let now = Instant::now();
        let status = || -> Status {
            serde_json::from_slice(&fs::read(directory.join("status.json")).unwrap()).unwrap()
        };
        if let crate::match_service::MatchService::Worker(worker) = &mut rt.match_service {
            worker.booted_at = now - Duration::from_secs(59);
        }
        rt.tick_match_service(now);
        assert_eq!(status().phase, Phase::Ready, "still waiting at 59 s");
        if let crate::match_service::MatchService::Worker(worker) = &mut rt.match_service {
            worker.booted_at = now - Duration::from_secs(60);
            worker.last_status = None;
        }
        rt.tick_match_service(now);
        assert!(
            matches!(status().phase, Phase::Failed | Phase::Settling),
            "nobody came: the arena is given up"
        );
        fs::remove_dir_all(directory).unwrap();
    }

    /// A worker's receipt names the humans who joined, so the lobby knows
    /// whom to re-queue when the allocation ends before its match (LR-32).
    #[test]
    fn the_receipt_names_the_humans_who_joined() {
        let (mut rt, addr, join) = fixture();
        let directory = rt.match_service.worker().unwrap().directory.clone();
        fs::create_dir_all(&directory).unwrap();
        let now = Instant::now();
        rt.tick_match_service(now);
        let before: Status =
            serde_json::from_slice(&fs::read(directory.join("status.json")).unwrap()).unwrap();
        assert!(before.joined_sessions.is_empty());
        rt.handle_packet(addr, join, now);
        if let crate::match_service::MatchService::Worker(worker) = &mut rt.match_service {
            worker.last_status = None;
        }
        rt.tick_match_service(now + Duration::from_secs(1));
        let after: Status =
            serde_json::from_slice(&fs::read(directory.join("status.json")).unwrap()).unwrap();
        assert_eq!(after.joined_sessions, vec!["seat-a".to_owned()]);
        assert!(rt.match_service.worker().unwrap().saw_human);
        fs::remove_dir_all(directory).unwrap();
    }
}
