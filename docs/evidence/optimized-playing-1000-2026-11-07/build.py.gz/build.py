from pathlib import Path
import hashlib, json, os, shutil, subprocess, time, tomllib

root=Path.cwd(); out=root/'.agent/codex-ranked-readiness/load-opt1'
proof=json.loads((root/'docs/evidence/terminal-spool-replay-2026-11-07/summary.json').read_text())
for name,digest in proof['production_source_sha256'].items():
    assert hashlib.sha256((root/name).read_bytes()).hexdigest()==digest,name
records=json.loads((root/'.agent/codex-ranked-readiness/ready-runtime/server-compile.json').read_text())['commands']
shared=json.loads((root/'.agent/codex-ranked-readiness/queue-discipline/compile.json').read_text())['commands'][0]
store=json.loads((root/'.agent/codex-ranked-readiness/ready-runtime/legacy-build-compile.json').read_text())['commands'][0]
harness=json.loads((root/'.agent/codex-ranked-readiness/load-cadence/build.json').read_text())['commands']
mapping={name:str(out/('lib'+name+'.rlib')) for name in ('shared','common','omoba_passport','omoba_career_store','harness')}
native=[v for i,v in enumerate(records[0]['command']) if i and records[0]['command'][i-1]=='-L' and v.startswith('native=')]
base=['rustc','--edition=2024','--crate-name','shared',str(root/'shared/src/lib.rs'),'--crate-type=rlib','-o',mapping['shared'],'-L','dependency=/Volumes/Orico/omoba-build-cache/target-b/debug/deps']
for k,v in shared['dependencies'].items():base+=['--extern',k+'='+v]
for value in native:base+=['-L',value]
jobs=[('shared',base),('common',records[0]['command']),('passport',records[1]['command']),('career-store',store),('server',records[2]['command']),('harness',harness[0]),('bots',harness[1]),('transport-tests',harness[2])]
env={k:v for k,v in os.environ.items() if not k.startswith('OMOBA_')}
env.update(CARGO_PKG_VERSION=tomllib.loads((root/'Cargo.toml').read_text())['workspace']['package']['version'],CARGO=shutil.which('cargo'))
report={'status':'building','source':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'commands':[],'minimum_root_gib':shutil.disk_usage('/').free/2**30,'scope':'Only renderer-free workspace roots opt1, debug assertions/overflow enabled, existing coherent third-party libraries read-only; no Cargo, SDK, Bevy or platform compilation','opt_flags':['opt-level=1','debug-assertions=yes','overflow-checks=yes','debuginfo=0','codegen-units=256']}
for name,original in jobs:
    cmd=original.copy()
    cmd=[v for v in cmd if v!='--emit=metadata']
    if name=='server':cmd.remove('--test')
    if name=='common':
        pos=cmd.index('--cfg');assert cmd[pos+1]=='feature="test-support"';del cmd[pos:pos+2]
    for i,value in enumerate(cmd):
        if '=' in value and value.split('=',1)[0] in mapping:
            key=value.split('=',1)[0];cmd[i]=key+'='+mapping[key]
    target=out/('lib'+{'passport':'omoba_passport','career-store':'omoba_career_store'}.get(name,name)+'.rlib') if name in ('shared','common','passport','career-store','harness') else out/name
    cmd[cmd.index('-o')+1]=str(target)
    cmd+=['-L','dependency='+str(out)]
    for flag in report['opt_flags']:cmd+=['-C',flag]
    cmd+=['-C','metadata=omoba-headless-opt1-20261107']
    env['CARGO_MANIFEST_DIR']=str(root/('harness' if name in ('harness','bots','transport-tests') else name))
    started=time.monotonic()
    with (out/(name+'.log')).open('w') as log:
        result=subprocess.run(cmd,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=480)
    item={'name':name,'command':cmd,'exit':result.returncode,'seconds':time.monotonic()-started,'output_sha256':hashlib.sha256(target.read_bytes()).hexdigest() if target.exists() else None}
    report['commands'].append(item);report['minimum_root_gib']=min(report['minimum_root_gib'],shutil.disk_usage('/').free/2**30)
    (out/'build.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps({k:item[k] for k in ('name','exit','seconds')}),flush=True)
    assert result.returncode==0, (out/(name+'.log')).read_text()[-3000:]
    assert sum(p.stat().st_size for p in out.iterdir() if p.is_file())<512*2**20,'unexpected headless artifact size'
report['status']='PASS'
report['source_sha256']={str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for directory in ('shared','common','passport','career-store','server','harness') for p in sorted((root/directory/'src').rglob('*.rs'))}
(out/'build.json').write_text(json.dumps(report,indent=2)+'\n')
with (out/'transport-tests.log').open('w') as log:subprocess.run([str(out/'transport-tests'),'--test-threads=1'],check=True,stdout=log,stderr=subprocess.STDOUT)
print('PASS coherent opt1 headless graph and3 actual UDP cases',flush=True)
